/**
Testing Program for Creating Classes Lab
@author Nicholas Lorentzen and Nate Harris
@version 2018-10-12
*/

public class ClassTest
{
   public static void main(String[] args)
   {
      Rocket test = new Rocket();
      System.out.println("Actual: " + test);
      System.out.println("Expected: Rocket: Jebediah Kerman MKII," + 
         "has the rocket exploded = false, is the engine running = true");
   }
}
