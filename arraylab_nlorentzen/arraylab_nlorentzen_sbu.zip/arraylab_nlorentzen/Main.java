class Main 
{
   public static void main(String[] args)
   {
      BattleGame theGame = new BattleGame();
      
      theGame.run();
   }
}